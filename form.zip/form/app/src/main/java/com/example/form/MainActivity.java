package com.example.form;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nameEditText, nimEditText, emailEditText;
    Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEditText = findViewById(R.id.name_edit_text);
        nimEditText = findViewById(R.id.nim_edit_text);
        emailEditText = findViewById(R.id.email_edit_text);
        submitButton = findViewById(R.id.register_button);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameEditText.getText().toString();
                String email = emailEditText.getText().toString();
                Toast.makeText(MainActivity.this, "Name: " + name + "\nEmail: " + email, Toast.LENGTH_SHORT).show();
            }
        });
    }
}